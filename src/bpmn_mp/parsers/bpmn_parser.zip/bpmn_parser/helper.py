from pathlib import Path
import xml.etree.ElementTree as ET
from typing import Union, List, Dict, Optional, Tuple


def parse_extended_attribute_definitions(collab_elem: ET.Element) -> Dict[str, dict]:
    """
    Parse seluruh BizagiExtendedAttributeDefinition dalam collaboration.
    Output: dictionary dengan ID sebagai key.
    """
    definitions = {}

    ns = {"bizagi": "http://www.bizagi.com/bpmn20"}
    for def_elem in collab_elem.findall(".//bizagi:BizagiExtendedAttributeDefinition", ns):
        attr_id = def_elem.attrib.get("Id")
        attr_type = def_elem.attrib.get("Type")
        name_elem = def_elem.find("bizagi:Name", ns)
        desc_elem = def_elem.find("bizagi:Description", ns)
        options_elem = def_elem.find("bizagi:Options", ns)
        elem_types = def_elem.find("bizagi:ElementTypes", ns)

        options = []
        if options_elem is not None:
            options = [opt.text for opt in options_elem.findall("bizagi:string", ns) if opt.text]

        types = []
        if elem_types is not None:
            types = [et.attrib.get("Type") for et in elem_types.findall("bizagi:AttributeElementType", ns)]

        definitions[attr_id] = {
            "id": attr_id,
            "type": attr_type,
            "name": name_elem.text if name_elem is not None else "",
            "description": desc_elem.text if desc_elem is not None else "",
            "options": options,
            "elementTypes": types
        }

    return definitions


def parse_extended_attribute_values(ext_elem: ET.Element) -> List[dict]:
    """
    Parse seluruh BizagiExtendedAttributeValue di dalam satu elemen BPMN.
    Output: list of dict.
    """
    results = []
    ns = {"bizagi": "http://www.bizagi.com/bpmn20"}
    values_root = ext_elem.find(".//bizagi:BizagiExtendedAttributeValues", ns)
    if values_root is None:
        return []

    for val in values_root.findall("bizagi:BizagiExtendedAttributeValue", ns):
        attr_id = val.attrib.get("Id")
        attr_type = val.attrib.get("Type")
        content = val.findtext("bizagi:Content", default="", namespaces=ns)
        display = val.findtext("bizagi:DisplayValue", default="", namespaces=ns)

        # TableValues
        table = []
        for row in val.findall(".//bizagi:RowValues", ns):
            row_data = []
            for cell in row.findall("bizagi:ExtendedAttributeValue", ns):
                row_data.append({
                    "id": cell.attrib.get("Id"),
                    "type": cell.attrib.get("Type"),
                    "content": cell.findtext("bizagi:Content", default="", namespaces=ns)
                })
            table.append(row_data)

        results.append({
            "id": attr_id,
            "type": attr_type,
            "content": content,
            "displayValue": display,
            "tableValues": table
        })

    return results


def build_lane_and_pool_mappings(root: ET.Element) -> Tuple[Dict[str, str], Dict[str, str]]:
    lane_map = {}
    pool_map = {}

    # Mapping lane_id → flow elements
    for lane in root.findall(".//{*}lane"):
        lane_id = lane.attrib.get("id")
        for node_ref in lane.findall(".//{*}flowNodeRef"):
            elem_id = node_ref.text
            if elem_id:
                lane_map[elem_id] = lane_id

    # Mapping process_id → pool_id
    participant_list = root.findall(".//{*}participant")
    process_to_pool = {
        p.attrib.get("processRef"): p.attrib.get("id")
        for p in participant_list if p.attrib.get("processRef") and p.attrib.get("id")
    }

    for process in root.findall(".//{*}process"):
        process_id = process.attrib.get("id")
        pool_id = process_to_pool.get(process_id)
        if not pool_id:
            continue

        # Ambil semua flow elements dalam process
        for elem in process.iter():
            elem_id = elem.attrib.get("id")
            if elem_id:
                pool_map[elem_id] = pool_id

    return lane_map, pool_map



def get_element_text_list(elem: ET.Element, tag_name: str) -> List[str]:
    return [child.text for child in elem.findall(f".//{tag_name}") if child.text]


def get_clean_tag(tag: str) -> str:
    return tag.split("}")[-1] if "}" in tag else tag


def parse_xml_file(xml_file: Union[str, Path]) -> ET.Element:
    tree = ET.parse(xml_file)
    return tree.getroot()


def parse_element(elem: ET.Element) -> dict:
    """
    Parse satu elemen BPMN menjadi dictionary standar.
    """
    tag = get_clean_tag(elem.tag)
    elem_id = elem.attrib.get("id")
    elem_name = elem.attrib.get("name", "")

    # Ambil incoming dan outgoing
    incoming = get_element_text_list(elem, "{*}incoming")
    outgoing = get_element_text_list(elem, "{*}outgoing")

    # Ambil documentation
    doc_node = elem.find(".//{*}documentation")
    documentation = doc_node.text if doc_node is not None else ""

    # Ambil extensionElements
    extension_node = elem.find(".//{*}extensionElements")
    extended_values = parse_extended_attribute_values(extension_node) if extension_node is not None else []

    return {
        "id": elem_id,
        "name": elem_name,
        "type": tag.lower(),
        "subType": tag,
        "incoming": incoming,
        "outgoing": outgoing,
        "documentation": documentation,
        "extensionElements": {
            "bizagi": {
                "extendedAttributeValues": extended_values
            }
        },
        "position": {},
        "properties": {
            "pool_id": None,
            "lane_id": None,
            "label": None
        }
    }

import xml.etree.ElementTree as ET
from pathlib import Path
from app.core.parsers.bpmn_parser.helper import (
    get_clean_tag,
    parse_xml_file,
    parse_element,
    build_lane_and_pool_mappings
)


def parse_file(filepath: str) -> dict:
    """
    Parse file .bpmn (standar BPMN 2.0 XML) menjadi format JSON terstruktur.
    """
    result = {
        "flowElements": [],
        "messageFlows": [],
        "pools": [],
        "lanes": []
    }

    root = parse_xml_file(filepath)

    # Dapatkan mapping element ID ke lane dan pool
    lane_map, pool_map = build_lane_and_pool_mappings(root)

    # Cari tag utama <bpmn:process>
    process_nodes = [n for n in root.iter() if get_clean_tag(n.tag).lower() == "process"]
    if not process_nodes:
        raise ValueError("❌ Tidak ditemukan elemen <process> dalam file BPMN.")

    for process_node in process_nodes:
            for elem in process_node.iter():
                tag = get_clean_tag(elem.tag).lower()
                if tag in [
                    "task", "usertask", "manualtask", "servicetask",
                    "startevent", "endevent", "intermediatethrowevent",
                    "exclusivegateway", "inclusivegateway", "parallelgateway",
                    "sequenceflow"
                ]:
                    parsed = parse_element(elem)
                    parsed["properties"]["lane_id"] = lane_map.get(parsed["id"])
                    parsed["properties"]["pool_id"] = pool_map.get(parsed["id"])
                    result["flowElements"].append(parsed)


    # Tambahkan messageFlow jika ada
    for elem in root.findall(".//{*}messageFlow"):
        parsed = parse_element(elem)
        parsed["properties"]["lane_id"] = lane_map.get(parsed["id"])
        parsed["properties"]["pool_id"] = pool_map.get(parsed["id"])
        parsed["incoming"] = [elem.attrib.get("sourceRef")] if elem.attrib.get("sourceRef") else []
        parsed["outgoing"] = [elem.attrib.get("targetRef")] if elem.attrib.get("targetRef") else []
        result["messageFlows"].append(parsed)

    # Tambahkan participant sebagai pool
    for elem in root.findall(".//{*}participant"):
        result["pools"].append({
            "id": elem.attrib.get("id"),
            "name": elem.attrib.get("name"),
            "processRef": elem.attrib.get("processRef")
        })

    # Tambahkan lane jika ada
    for elem in root.findall(".//{*}lane"):
        result["lanes"].append({
            "id": elem.attrib.get("id"),
            "name": elem.attrib.get("name", ""),
            "flowNodeRefs": [n.text for n in elem.findall(".//{*}flowNodeRef") if n.text]
        })

    return result
